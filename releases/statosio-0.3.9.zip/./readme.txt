=== Plugin Name ===
Contributors: a6b8
Donate link: https://www.paypal.com/donate?hosted_button_id=XKYLQ9FBGC4RG
Tags: bar chart, d3, statosio
Tested up to: 5.7
Stable tag: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html